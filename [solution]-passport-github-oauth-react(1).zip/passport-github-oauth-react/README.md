# Codealong for OAuth and Passport

## Running

Update `/server/.env` file with your own Github App credentials

Make sure you install packages for client and server folders running `npm install`

`npm start`



