import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header>
        <h2>React App</h2>
        <nav>
          <a href="./">Home</a>
          {' | '}
          <a href="./">About</a>
          {' | '}
          <a href="./">Contact</a>
        </nav>
      </header>
      <section className="hero">
        <h1>Hero</h1>
      </section>
      <main>
        <article className="post">
          <h3>Post Title</h3>
          <p>
          Sit cillum est cupidatat sit. Veniam deserunt do eu irure. Anim aute magna aute aliquip deserunt pariatur esse dolor velit pariatur non ut est. Exercitation occaecat est adipisicing qui nisi cillum. Eiusmod fugiat consectetur et in excepteur amet nostrud eiusmod eiusmod.Velit pariatur velit non Lorem tempor aute excepteur deserunt.
          </p>
          <p>
          Ut duis voluptate in labore anim ad cupidatat enim duis amet sunt Lorem labore. Minim Lorem ea nulla ad sit labore adipisicing anim qui consectetur aute laboris. Sunt tempor reprehenderit veniam id pariatur.
          </p>
          <p>
            Ad enim est deserunt id. Cillum est nostrud id ad excepteur est aliquip cupidatat ex aute.Est nulla officia adipisicing id enim deserunt aute. Laborum nulla quis est labore nulla. Cupidatat sunt anim fugiat Lorem in minim laborum proident proident sint laborum quis consectetur irure.
          </p>
          <p>
            Ad enim est deserunt id. Cillum est nostrud id ad excepteur est aliquip cupidatat ex aute.Est nulla officia adipisicing id enim deserunt aute. Laborum nulla quis est labore nulla. Cupidatat sunt anim fugiat Lorem in minim laborum proident proident sint laborum quis consectetur irure.
          </p>
          <p>
            Ad enim est deserunt id. Cillum est nostrud id ad excepteur est aliquip cupidatat ex aute.Est nulla officia adipisicing id enim deserunt aute. Laborum nulla quis est labore nulla. Cupidatat sunt anim fugiat Lorem in minim laborum proident proident sint laborum quis consectetur irure.
          </p>
        </article>
        <aside className="categories">
          <h4>Categories</h4>
          <ul className="categories__list">
            <li><a href="./">Category 1</a></li>
            <li><a href="./">Category 2</a></li>
            <li><a href="./">Category 3</a></li>
            <li><a href="./">Category 4</a></li>
            <li><a href="./">Category 5</a></li>
            <li><a href="./">Category 6</a></li>
          </ul>
        </aside>
      </main>
      <footer>
        <div><a href="./">Site Map</a></div>
        <div>Copyright 20xx</div>
      </footer>
    </div>
  );
}

export default App;
