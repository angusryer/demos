# Tweet Server
### `Morning Challenge | express & node.js`

## Learning Objectives
- understand how to execute code with Node.js
- understand how to setup a REST based express server, with some endpoints
- test the data of the mock server made using Postman or other HTTP client
- how to use express middleware
- writing to a file & reading from a file

## Instructions
Create an express server with the following end points:
1. `GET /tweets`: should return an array of all the tweets.
2. `POST /tweets`: should take a JSON object that will contain the tweet which looks like...
```json
{
  tweet: "This is my tweet"
}
```
and add it to an array of tweets. Use `body-parser` express [middleware](https://expressjs.com/en/guide/using-middleware.html) to get the information from the body of the POST. Your server should make a new `id` for every tweet that is added through this endpoint.
3. Save the tweets to a file, so if the server restarts, the tweets aren't lost. 
4. Tweets should be loaded from that file when the server starts. The file should be updated when a new tweet is added. To do this and step 3, you need to use the `fs` Node.js library. You may also need to use `JSON.parse()` and `JSON.stringify()`.
5. Any errors should return a response of status `400` with an object detailing the error:
```json
{
  success: false,
  message: 'your error message here'
}
```

### Example tweets array that you need to store:
```javascript
const tweets = [
  {
    'tweet': 'What a day!',
    'id': 0
  },
  {
    'tweet': 'I am addicted to pizza.',
    'id': 1
  },
  {
    'tweet': 'Going to the beach today',
    'id': 2
  },
  {
    'tweet': 'Thinking of bugs at 2am in the morning...',
    'id': 3
  }
];
```
