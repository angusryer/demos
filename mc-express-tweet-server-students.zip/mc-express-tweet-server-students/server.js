const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');
const { v4 : uuid } = require('uuid');
const tweets = require('./tweets.json');

// console.log(tweets);

app.use(bodyParser.json());

app.get('/tweets', (_req, res) => {
    res.status(200).send({
        data: tweets
    })
})

function prepareToWrite(tweet) {
    tweets.tweets.push(tweet);
    writeToFile(tweets)
}

function writeToFile(allTweets) {
    return new Promise((res, rej) => {
        fs.writeFile('./tweets.json', JSON.stringify(allTweets), err => {
            if (err) {
                rej('could not write to file');
            } else {
                res('successfully updated tweets');
            }
        })
    })
}

app.post('/tweets', (req, res) => {
    if (req.body.tweet) {
        prepareToWrite({
            tweet: req.body.tweet,
            id: uuid()
        })
        res.status(200).send({
            data: tweets
        })
    } else {
        res.status(400).send({
            success: false,
            message: 'Enter valid tweet please'
        })
    }
})

app.listen(8080, () => console.log('Listening on port 8080'))